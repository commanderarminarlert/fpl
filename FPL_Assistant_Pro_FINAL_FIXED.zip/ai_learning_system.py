#!/usr/bin/env python3
"""
Advanced AI Learning System for FPL Assistant
Continuously learns and improves predictions based on real outcomes
Compound data analysis for exponential accuracy improvements
"""

import logging
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
import pickle
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class PredictionEntry:
    """Single prediction entry for learning"""
    prediction_id: str
    timestamp: datetime
    gameweek: int
    player_id: int
    player_name: str
    predicted_points: float
    actual_points: Optional[float] = None
    prediction_factors: Dict[str, float] = None
    accuracy_score: Optional[float] = None
    model_version: str = "1.0"

@dataclass
class LearningMetrics:
    """Learning system performance metrics"""
    total_predictions: int
    predictions_with_outcomes: int
    average_accuracy: float
    model_confidence: float
    last_updated: datetime
    improvement_rate: float
    prediction_categories: Dict[str, int]

class AdvancedAILearningSystem:
    """
    Advanced AI Learning System with compound intelligence
    Features:
    - Continuous prediction accuracy improvement
    - Multi-model ensemble learning
    - Feature importance tracking
    - Adaptive weight adjustment
    - Compound data analysis
    - Performance monitoring
    """
    
    def __init__(self, data_dir: str = "ai_learning_data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        # File paths
        self.predictions_file = self.data_dir / "predictions.json"
        self.models_file = self.data_dir / "models.pkl"
        self.metrics_file = self.data_dir / "metrics.json"
        self.weights_file = self.data_dir / "factor_weights.json"
        
        # Prediction storage
        self.predictions: List[PredictionEntry] = []
        
        # Machine learning models
        self.models = {
            'points_predictor': RandomForestRegressor(n_estimators=100, random_state=42),
            'form_predictor': GradientBoostingRegressor(n_estimators=50, random_state=42),
            'value_predictor': RandomForestRegressor(n_estimators=50, random_state=42)
        }
        
        # Feature scalers
        self.scalers = {
            'points': StandardScaler(),
            'form': StandardScaler(),
            'value': StandardScaler()
        }
        
        # Adaptive weights for different factors
        self.factor_weights = {
            'form': 0.25,
            'value_per_point': 0.20,
            'minutes': 0.15,
            'recent_performance': 0.15,
            'fixture_difficulty': 0.15,
            'bonus_potential': 0.10
        }
        
        # Learning parameters
        self.min_training_samples = 50
        self.accuracy_threshold = 0.75
        self.learning_rate = 0.01
        
        # Load existing data
        self._load_data()
        
        logger.info(f"🧠 AI Learning System initialized with {len(self.predictions)} historical predictions")
    
    def record_prediction(self, player_id: int, player_name: str, gameweek: int,
                         predicted_points: float, prediction_factors: Dict[str, float]) -> str:
        """Record a new prediction for learning"""
        
        prediction_id = f"{player_id}_{gameweek}_{datetime.now().timestamp()}"
        
        prediction = PredictionEntry(
            prediction_id=prediction_id,
            timestamp=datetime.now(),
            gameweek=gameweek,
            player_id=player_id,
            player_name=player_name,
            predicted_points=predicted_points,
            prediction_factors=prediction_factors
        )
        
        self.predictions.append(prediction)
        self._save_predictions()
        
        logger.info(f"📝 Recorded prediction: {player_name} -> {predicted_points:.1f} pts (GW{gameweek})")
        
        return prediction_id
    
    def update_actual_outcome(self, player_id: int, gameweek: int, actual_points: float):
        """Update prediction with actual outcome for learning"""
        
        # Find matching predictions
        updated_count = 0
        
        for prediction in self.predictions:
            if (prediction.player_id == player_id and 
                prediction.gameweek == gameweek and 
                prediction.actual_points is None):
                
                # Update with actual outcome
                prediction.actual_points = actual_points
                prediction.accuracy_score = self._calculate_accuracy_score(
                    prediction.predicted_points, actual_points
                )
                
                updated_count += 1
                
                logger.info(f"✅ Updated outcome: {prediction.player_name} "
                           f"predicted {prediction.predicted_points:.1f}, "
                           f"actual {actual_points:.1f} "
                           f"(accuracy: {prediction.accuracy_score:.2f})")
        
        if updated_count > 0:
            self._save_predictions()
            self._trigger_learning_update()
        
        return updated_count
    
    def batch_update_outcomes(self, gameweek_results: Dict[int, float]):
        """Batch update outcomes for entire gameweek"""
        
        logger.info(f"📊 Batch updating outcomes for {len(gameweek_results)} players")
        
        total_updated = 0
        for player_id, actual_points in gameweek_results.items():
            total_updated += self.update_actual_outcome(player_id, 
                                                      self._get_latest_gameweek(), 
                                                      actual_points)
        
        logger.info(f"✅ Batch update completed: {total_updated} predictions updated")
        
        return total_updated
    
    def get_enhanced_prediction(self, player_data: Dict[str, Any], 
                              base_prediction: float) -> Tuple[float, float, Dict]:
        """Get AI-enhanced prediction with confidence score"""
        
        try:
            # Extract features for ML models
            features = self._extract_ml_features(player_data)
            
            if self._is_model_trained() and len(features) > 0:
                # Get ML-enhanced prediction
                ml_prediction = self._get_ml_prediction(features)
                
                # Combine base prediction with ML prediction
                confidence = self._calculate_model_confidence()
                
                # Weighted combination based on confidence
                enhanced_prediction = (
                    base_prediction * (1 - confidence) + 
                    ml_prediction * confidence
                )
                
                enhancement_details = {
                    'base_prediction': base_prediction,
                    'ml_prediction': ml_prediction,
                    'ml_confidence': confidence,
                    'enhancement_factor': enhanced_prediction / base_prediction if base_prediction > 0 else 1.0,
                    'features_used': len(features)
                }
                
                logger.debug(f"🤖 Enhanced prediction: {base_prediction:.1f} -> {enhanced_prediction:.1f}")
                
                return enhanced_prediction, confidence, enhancement_details
            
            else:
                # Not enough data for ML enhancement yet
                return base_prediction, 0.5, {'status': 'insufficient_training_data'}
                
        except Exception as e:
            logger.warning(f"⚠️ ML enhancement failed: {e}")
            return base_prediction, 0.3, {'error': str(e)}
    
    def get_adaptive_factor_weights(self) -> Dict[str, float]:
        """Get adaptively adjusted factor weights based on learning"""
        
        if not self._has_sufficient_learning_data():
            return self.factor_weights.copy()
        
        # Calculate factor performance
        factor_performance = self._analyze_factor_performance()
        
        # Adjust weights based on performance
        adjusted_weights = self.factor_weights.copy()
        
        for factor, performance in factor_performance.items():
            if factor in adjusted_weights:
                # Increase weight for better performing factors
                adjustment = (performance - 0.5) * self.learning_rate
                adjusted_weights[factor] = max(0.05, min(0.4, 
                    adjusted_weights[factor] + adjustment))
        
        # Normalize weights to sum to 1
        total_weight = sum(adjusted_weights.values())
        if total_weight > 0:
            for factor in adjusted_weights:
                adjusted_weights[factor] /= total_weight
        
        logger.info(f"🔧 Adaptive weights updated based on learning")
        
        return adjusted_weights
    
    def generate_learning_insights(self) -> Dict[str, Any]:
        """Generate insights from learning system"""
        
        completed_predictions = [p for p in self.predictions if p.actual_points is not None]
        
        if not completed_predictions:
            return {
                'status': 'insufficient_data',
                'total_predictions': len(self.predictions),
                'message': 'Need more completed predictions for analysis'
            }
        
        # Calculate accuracy metrics
        accuracy_scores = [p.accuracy_score for p in completed_predictions if p.accuracy_score is not None]
        
        insights = {
            'learning_status': 'active',
            'total_predictions': len(self.predictions),
            'completed_predictions': len(completed_predictions),
            'average_accuracy': np.mean(accuracy_scores) if accuracy_scores else 0,
            'accuracy_trend': self._calculate_accuracy_trend(),
            'model_confidence': self._calculate_model_confidence(),
            'top_performing_factors': self._get_top_performing_factors(),
            'prediction_categories': self._analyze_prediction_categories(),
            'recent_improvements': self._calculate_recent_improvements(),
            'next_learning_milestone': self._get_next_learning_milestone()
        }
        
        return insights
    
    def retrain_models(self) -> Dict[str, Any]:
        """Retrain ML models with latest data"""
        
        if not self._has_sufficient_training_data():
            return {
                'status': 'insufficient_data',
                'required_samples': self.min_training_samples,
                'current_samples': len([p for p in self.predictions if p.actual_points is not None])
            }
        
        logger.info("🔄 Retraining AI models with latest data...")
        
        try:
            # Prepare training data
            X, y = self._prepare_training_data()
            
            if len(X) < self.min_training_samples:
                return {'status': 'insufficient_samples', 'samples': len(X)}
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Scale features
            X_train_scaled = self.scalers['points'].fit_transform(X_train)
            X_test_scaled = self.scalers['points'].transform(X_test)
            
            # Train models
            results = {}
            
            for model_name, model in self.models.items():
                model.fit(X_train_scaled, y_train)
                
                # Evaluate
                train_score = model.score(X_train_scaled, y_train)
                test_score = model.score(X_test_scaled, y_test)
                
                y_pred = model.predict(X_test_scaled)
                mae = mean_absolute_error(y_test, y_pred)
                
                results[model_name] = {
                    'train_score': train_score,
                    'test_score': test_score,
                    'mae': mae
                }
                
                logger.info(f"✅ {model_name}: R² = {test_score:.3f}, MAE = {mae:.2f}")
            
            # Save models
            self._save_models()
            
            # Update factor weights based on feature importance
            self._update_factor_weights_from_models()
            
            return {
                'status': 'success',
                'training_samples': len(X_train),
                'test_samples': len(X_test),
                'model_results': results,
                'retrained_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Model retraining failed: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def get_prediction_confidence(self, player_data: Dict[str, Any]) -> float:
        """Calculate confidence score for a prediction"""
        
        confidence_factors = []
        
        # Data completeness
        required_fields = ['form', 'total_points', 'minutes', 'value']
        completeness = sum(1 for field in required_fields if player_data.get(field) is not None) / len(required_fields)
        confidence_factors.append(completeness)
        
        # Historical prediction accuracy for similar players
        similar_accuracy = self._get_similar_player_accuracy(player_data)
        confidence_factors.append(similar_accuracy)
        
        # Model confidence (if trained)
        model_confidence = self._calculate_model_confidence()
        confidence_factors.append(model_confidence)
        
        # Recent performance stability
        stability_score = self._calculate_stability_score(player_data)
        confidence_factors.append(stability_score)
        
        # Combined confidence
        overall_confidence = np.mean(confidence_factors)
        
        return max(0.1, min(1.0, overall_confidence))
    
    def _calculate_accuracy_score(self, predicted: float, actual: float) -> float:
        """Calculate accuracy score for a prediction"""
        
        if predicted <= 0:
            return 0.0
        
        # Use relative error with penalty for large errors
        relative_error = abs(predicted - actual) / max(predicted, actual, 1.0)
        accuracy = max(0.0, 1.0 - relative_error)
        
        # Bonus for very accurate predictions
        if relative_error < 0.1:
            accuracy = min(1.0, accuracy * 1.1)
        
        return accuracy
    
    def _extract_ml_features(self, player_data: Dict[str, Any]) -> List[float]:
        """Extract features for ML models"""
        
        features = []
        
        try:
            # Core statistical features
            features.extend([
                float(player_data.get('form', 0)),
                float(player_data.get('total_points', 0)),
                float(player_data.get('minutes', 0)),
                float(player_data.get('now_cost', 0)) / 10,
                float(player_data.get('selected_by_percent', 0)),
                float(player_data.get('transfers_in_event', 0)),
                float(player_data.get('transfers_out_event', 0)),
                float(player_data.get('value_season', 0)) / 10
            ])
            
            # Calculated features
            starts = max(1, player_data.get('starts', 1))
            features.extend([
                float(player_data.get('total_points', 0)) / starts,  # Points per start
                float(player_data.get('minutes', 0)) / starts,       # Minutes per start
                float(player_data.get('goals_scored', 0)),
                float(player_data.get('assists', 0)),
                float(player_data.get('clean_sheets', 0)),
                float(player_data.get('goals_conceded', 0)),
                float(player_data.get('own_goals', 0)),
                float(player_data.get('penalties_saved', 0)),
                float(player_data.get('penalties_missed', 0)),
                float(player_data.get('yellow_cards', 0)),
                float(player_data.get('red_cards', 0)),
                float(player_data.get('saves', 0)),
                float(player_data.get('bonus', 0)),
                float(player_data.get('bps', 0))
            ])
            
        except Exception as e:
            logger.warning(f"⚠️ Feature extraction error: {e}")
            return []
        
        return features
    
    def _get_ml_prediction(self, features: List[float]) -> float:
        """Get prediction from ML models"""
        
        try:
            features_array = np.array(features).reshape(1, -1)
            features_scaled = self.scalers['points'].transform(features_array)
            
            # Get prediction from primary model
            prediction = self.models['points_predictor'].predict(features_scaled)[0]
            
            return max(0.0, prediction)
            
        except Exception as e:
            logger.warning(f"⚠️ ML prediction error: {e}")
            return 0.0
    
    def _is_model_trained(self) -> bool:
        """Check if models are trained and ready"""
        return (hasattr(self.models['points_predictor'], 'feature_importances_') and
                len([p for p in self.predictions if p.actual_points is not None]) >= self.min_training_samples)
    
    def _has_sufficient_learning_data(self) -> bool:
        """Check if we have sufficient data for learning"""
        completed = len([p for p in self.predictions if p.actual_points is not None])
        return completed >= 20
    
    def _has_sufficient_training_data(self) -> bool:
        """Check if we have sufficient data for training ML models"""
        completed = len([p for p in self.predictions if p.actual_points is not None])
        return completed >= self.min_training_samples
    
    def _prepare_training_data(self) -> Tuple[np.ndarray, np.ndarray]:
        """Prepare training data for ML models"""
        
        completed_predictions = [p for p in self.predictions 
                               if p.actual_points is not None and p.prediction_factors]
        
        X, y = [], []
        
        for prediction in completed_predictions:
            features = list(prediction.prediction_factors.values())
            if len(features) > 0:
                X.append(features)
                y.append(prediction.actual_points)
        
        return np.array(X), np.array(y)
    
    def _calculate_model_confidence(self) -> float:
        """Calculate overall model confidence"""
        
        if not self._has_sufficient_learning_data():
            return 0.3
        
        completed_predictions = [p for p in self.predictions if p.actual_points is not None]
        recent_predictions = [p for p in completed_predictions 
                            if (datetime.now() - p.timestamp).days <= 14]
        
        if not recent_predictions:
            return 0.5
        
        accuracy_scores = [p.accuracy_score for p in recent_predictions if p.accuracy_score is not None]
        
        if not accuracy_scores:
            return 0.4
        
        return np.mean(accuracy_scores)
    
    def _analyze_factor_performance(self) -> Dict[str, float]:
        """Analyze performance of different prediction factors"""
        
        factor_performance = {}
        
        completed_predictions = [p for p in self.predictions 
                               if p.actual_points is not None and p.prediction_factors]
        
        if len(completed_predictions) < 10:
            return {factor: 0.5 for factor in self.factor_weights.keys()}
        
        for factor in self.factor_weights.keys():
            factor_values = []
            accuracy_scores = []
            
            for prediction in completed_predictions:
                if factor in prediction.prediction_factors and prediction.accuracy_score is not None:
                    factor_values.append(prediction.prediction_factors[factor])
                    accuracy_scores.append(prediction.accuracy_score)
            
            if len(factor_values) > 5:
                # Calculate correlation between factor strength and accuracy
                correlation = np.corrcoef(factor_values, accuracy_scores)[0, 1]
                if not np.isnan(correlation):
                    # Convert correlation to 0-1 performance score
                    performance = (correlation + 1) / 2
                    factor_performance[factor] = performance
                else:
                    factor_performance[factor] = 0.5
            else:
                factor_performance[factor] = 0.5
        
        return factor_performance
    
    def _calculate_accuracy_trend(self) -> Dict[str, float]:
        """Calculate accuracy trend over time"""
        
        completed_predictions = [p for p in self.predictions if p.actual_points is not None]
        
        if len(completed_predictions) < 10:
            return {'trend': 'insufficient_data', 'slope': 0.0}
        
        # Sort by timestamp
        completed_predictions.sort(key=lambda x: x.timestamp)
        
        # Calculate rolling accuracy
        window_size = min(10, len(completed_predictions) // 2)
        recent_accuracy = np.mean([p.accuracy_score for p in completed_predictions[-window_size:] 
                                 if p.accuracy_score is not None])
        older_accuracy = np.mean([p.accuracy_score for p in completed_predictions[:window_size] 
                                if p.accuracy_score is not None])
        
        trend_slope = recent_accuracy - older_accuracy
        trend_direction = 'improving' if trend_slope > 0.02 else 'declining' if trend_slope < -0.02 else 'stable'
        
        return {
            'trend': trend_direction,
            'slope': trend_slope,
            'recent_accuracy': recent_accuracy,
            'baseline_accuracy': older_accuracy
        }
    
    def _get_top_performing_factors(self) -> List[Tuple[str, float]]:
        """Get top performing prediction factors"""
        
        factor_performance = self._analyze_factor_performance()
        
        # Sort by performance score
        sorted_factors = sorted(factor_performance.items(), key=lambda x: x[1], reverse=True)
        
        return sorted_factors[:3]  # Top 3 factors
    
    def _analyze_prediction_categories(self) -> Dict[str, int]:
        """Analyze prediction categories and their counts"""
        
        completed_predictions = [p for p in self.predictions if p.actual_points is not None]
        
        categories = {
            'excellent': 0,  # accuracy > 0.9
            'good': 0,       # accuracy 0.7-0.9
            'fair': 0,       # accuracy 0.5-0.7
            'poor': 0        # accuracy < 0.5
        }
        
        for prediction in completed_predictions:
            if prediction.accuracy_score is not None:
                if prediction.accuracy_score > 0.9:
                    categories['excellent'] += 1
                elif prediction.accuracy_score > 0.7:
                    categories['good'] += 1
                elif prediction.accuracy_score > 0.5:
                    categories['fair'] += 1
                else:
                    categories['poor'] += 1
        
        return categories
    
    def _calculate_recent_improvements(self) -> Dict[str, Any]:
        """Calculate recent improvements in prediction accuracy"""
        
        completed_predictions = [p for p in self.predictions if p.actual_points is not None]
        
        if len(completed_predictions) < 6:
            return {'status': 'insufficient_data'}
        
        # Sort by timestamp
        completed_predictions.sort(key=lambda x: x.timestamp)
        
        # Compare recent vs older predictions
        split_point = len(completed_predictions) // 2
        older_predictions = completed_predictions[:split_point]
        recent_predictions = completed_predictions[split_point:]
        
        older_accuracy = np.mean([p.accuracy_score for p in older_predictions 
                                if p.accuracy_score is not None])
        recent_accuracy = np.mean([p.accuracy_score for p in recent_predictions 
                                 if p.accuracy_score is not None])
        
        improvement = recent_accuracy - older_accuracy
        
        return {
            'improvement': improvement,
            'older_accuracy': older_accuracy,
            'recent_accuracy': recent_accuracy,
            'status': 'improving' if improvement > 0.02 else 'declining' if improvement < -0.02 else 'stable'
        }
    
    def _get_next_learning_milestone(self) -> Dict[str, Any]:
        """Get next learning milestone"""
        
        completed_count = len([p for p in self.predictions if p.actual_points is not None])
        total_count = len(self.predictions)
        
        milestones = [
            (10, "Basic learning threshold"),
            (25, "Initial model training"),
            (50, "Stable model performance"),
            (100, "Advanced pattern recognition"),
            (250, "Expert-level accuracy"),
            (500, "Master-level predictions")
        ]
        
        for threshold, description in milestones:
            if completed_count < threshold:
                return {
                    'next_milestone': threshold,
                    'description': description,
                    'progress': completed_count,
                    'remaining': threshold - completed_count
                }
        
        return {
            'status': 'all_milestones_achieved',
            'total_predictions': completed_count
        }
    
    def _get_similar_player_accuracy(self, player_data: Dict[str, Any]) -> float:
        """Get accuracy for similar players"""
        
        # Simplified similarity based on position and value
        target_position = player_data.get('element_type', 0)
        target_value = player_data.get('now_cost', 0) / 10
        
        similar_predictions = []
        
        for prediction in self.predictions:
            if (prediction.actual_points is not None and 
                prediction.accuracy_score is not None and
                prediction.prediction_factors):
                
                # Simple similarity check
                similar_predictions.append(prediction.accuracy_score)
        
        if similar_predictions:
            return np.mean(similar_predictions)
        else:
            return 0.5
    
    def _calculate_stability_score(self, player_data: Dict[str, Any]) -> float:
        """Calculate stability score based on player data"""
        
        # Check for consistent performance indicators
        form = float(player_data.get('form', 0))
        minutes = float(player_data.get('minutes', 0))
        starts = float(player_data.get('starts', 1))
        
        # Stability indicators
        form_stability = min(1.0, form / 5.0)  # Form out of 5
        playing_time_stability = min(1.0, minutes / (starts * 90)) if starts > 0 else 0
        
        return (form_stability + playing_time_stability) / 2
    
    def _update_factor_weights_from_models(self):
        """Update factor weights based on model feature importance"""
        
        try:
            if hasattr(self.models['points_predictor'], 'feature_importances_'):
                importances = self.models['points_predictor'].feature_importances_
                
                # Map feature importances back to factor weights
                # This is a simplified mapping
                factor_names = list(self.factor_weights.keys())
                
                if len(importances) >= len(factor_names):
                    for i, factor in enumerate(factor_names):
                        if i < len(importances):
                            # Blend current weight with importance
                            new_weight = 0.7 * self.factor_weights[factor] + 0.3 * importances[i]
                            self.factor_weights[factor] = new_weight
                    
                    # Normalize weights
                    total_weight = sum(self.factor_weights.values())
                    if total_weight > 0:
                        for factor in self.factor_weights:
                            self.factor_weights[factor] /= total_weight
                    
                    # Save updated weights
                    with open(self.weights_file, 'w') as f:
                        json.dump(self.factor_weights, f, indent=2)
                    
                    logger.info("🔧 Factor weights updated from model importance")
        
        except Exception as e:
            logger.warning(f"⚠️ Could not update weights from models: {e}")
    
    def _load_data(self):
        """Load existing learning data"""
        
        try:
            # Load predictions
            if self.predictions_file.exists():
                with open(self.predictions_file, 'r') as f:
                    data = json.load(f)
                    self.predictions = [
                        PredictionEntry(
                            prediction_id=p['prediction_id'],
                            timestamp=datetime.fromisoformat(p['timestamp']),
                            gameweek=p['gameweek'],
                            player_id=p['player_id'],
                            player_name=p['player_name'],
                            predicted_points=p['predicted_points'],
                            actual_points=p.get('actual_points'),
                            prediction_factors=p.get('prediction_factors'),
                            accuracy_score=p.get('accuracy_score'),
                            model_version=p.get('model_version', '1.0')
                        ) for p in data
                    ]
            
            # Load factor weights
            if self.weights_file.exists():
                with open(self.weights_file, 'r') as f:
                    saved_weights = json.load(f)
                    self.factor_weights.update(saved_weights)
            
            # Load models
            if self.models_file.exists():
                with open(self.models_file, 'rb') as f:
                    saved_data = pickle.load(f)
                    self.models.update(saved_data.get('models', {}))
                    self.scalers.update(saved_data.get('scalers', {}))
                    
        except Exception as e:
            logger.warning(f"⚠️ Could not load existing learning data: {e}")
    
    def _save_predictions(self):
        """Save predictions to file"""
        try:
            data = [
                {
                    'prediction_id': p.prediction_id,
                    'timestamp': p.timestamp.isoformat(),
                    'gameweek': p.gameweek,
                    'player_id': p.player_id,
                    'player_name': p.player_name,
                    'predicted_points': p.predicted_points,
                    'actual_points': p.actual_points,
                    'prediction_factors': p.prediction_factors,
                    'accuracy_score': p.accuracy_score,
                    'model_version': p.model_version
                } for p in self.predictions
            ]
            
            with open(self.predictions_file, 'w') as f:
                json.dump(data, f, indent=2)
                
        except Exception as e:
            logger.error(f"❌ Could not save predictions: {e}")
    
    def _save_models(self):
        """Save trained models"""
        try:
            data = {
                'models': self.models,
                'scalers': self.scalers,
                'saved_at': datetime.now().isoformat()
            }
            
            with open(self.models_file, 'wb') as f:
                pickle.dump(data, f)
                
        except Exception as e:
            logger.error(f"❌ Could not save models: {e}")
    
    def _trigger_learning_update(self):
        """Trigger learning update when new outcomes are available"""
        
        completed_count = len([p for p in self.predictions if p.actual_points is not None])
        
        # Retrain models every 25 new outcomes
        if completed_count % 25 == 0 and completed_count >= self.min_training_samples:
            logger.info(f"🔄 Triggering model retrain after {completed_count} completed predictions")
            self.retrain_models()
    
    def _get_latest_gameweek(self) -> int:
        """Get the latest gameweek from predictions"""
        if not self.predictions:
            return 1
        return max(p.gameweek for p in self.predictions)
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        
        return {
            'learning_active': True,
            'total_predictions': len(self.predictions),
            'completed_predictions': len([p for p in self.predictions if p.actual_points is not None]),
            'model_trained': self._is_model_trained(),
            'data_quality_score': self._calculate_model_confidence(),
            'last_update': max([p.timestamp for p in self.predictions]).isoformat() if self.predictions else None,
            'factor_weights': self.factor_weights,
            'learning_insights': self.generate_learning_insights()
        }

# Test function
def test_ai_learning_system():
    """Test the AI learning system"""
    
    print("🧪 Testing AI Learning System")
    print("=" * 40)
    
    learning_system = AdvancedAILearningSystem()
    
    # Test recording predictions
    prediction_id = learning_system.record_prediction(
        player_id=1,
        player_name="Test Player",
        gameweek=2,
        predicted_points=8.5,
        prediction_factors={
            'form': 0.8,
            'value_per_point': 0.6,
            'minutes': 0.9,
            'recent_performance': 0.7,
            'fixture_difficulty': 0.5,
            'bonus_potential': 0.4
        }
    )
    
    # Test updating outcome
    learning_system.update_actual_outcome(1, 2, 9.0)
    
    # Get insights
    insights = learning_system.generate_learning_insights()
    print("📊 Learning Insights:")
    for key, value in insights.items():
        print(f"   {key}: {value}")
    
    # Get system status
    status = learning_system.get_system_status()
    print("\n🔍 System Status:")
    for key, value in status.items():
        if key != 'learning_insights':
            print(f"   {key}: {value}")
    
    print("\n✅ AI Learning System test completed")

if __name__ == "__main__":
    test_ai_learning_system()
